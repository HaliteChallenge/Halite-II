public class Location
{
    public short x, y;
    
    public Location(short x_, short y_) {
        x = x_;
        y = y_;
    }
}
