public class Site
{
    public short owner, strength, production;
}
