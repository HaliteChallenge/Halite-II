public class Move
{
    public Location loc;
    public byte dir;
    
    public Move(Location loc_, byte dir_) {
        loc = loc_;
        dir = dir_;
    }
}
