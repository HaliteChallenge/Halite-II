
public class InitPackage
{
    public short playerTag;
    public Map map;
}
